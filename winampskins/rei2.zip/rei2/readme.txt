Ce skin a �t� cr�� par Morph�e morphee01@ifrance.com
Vous pouvez le trouver sur les sites :
http://ncorp.free.fr
http://ccorp.free.fr

Si vous voulez le mettre sur votre site, vous devez d'abord m'en demander l'autorisation et en pr�ciser sa provenance.

Si vous avez trouv� ce skin sur un site autre que ceux cit�s pr�c�dement, ou sur un site qui n'en pr�cisait pas sa provenance, veuillez m'en informer.

Morph�e